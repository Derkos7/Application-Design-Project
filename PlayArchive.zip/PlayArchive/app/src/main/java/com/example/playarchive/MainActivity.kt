package com.example.playarchive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.playarchive.ui.theme.PlayArchiveTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PlayArchiveTheme {
                Surface(modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { innerPadding ->
        NavHost(navController, startDestination = "home") {
            composable("home") { /* ... */ }
            composable("library") { /* ... */ }
            composable("profile") { /* ... */ }
            // Define other composable destinations here.
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    // Your BottomNavigationBar code
}

@Composable
fun Greeting(name: String) {
    Text(text = "Hello $name!")
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    PlayArchiveTheme {
        Greeting("Android")
    }
}
@Composable
fun GameButton(gameId: Int, gameDetailsActivityClass: Class<*>, gameDrawable: Int) {
    val context = LocalContext.current
    Button(onClick = {
        val intent = Intent(context, gameDetailsActivityClass)
        intent.putExtra("GAME_ID", gameId)
        context.startActivity(intent)
    }) {
        Icon(painter = painterResource(id = gameDrawable), contentDescription = "Game Image")
    }
}
